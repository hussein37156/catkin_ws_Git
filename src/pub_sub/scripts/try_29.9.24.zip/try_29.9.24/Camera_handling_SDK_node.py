#!/usr/bin/env python3

import pyzed.sl as sl
import rospy
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import Float32MultiArray
import cv2
from cv_bridge import CvBridge

rospy.init_node('camera_node')


image_pub = rospy.Publisher('/zed/image_raw', Image, queue_size=10)
point_cloud_pub = rospy.Publisher('/zed/point_cloud', PointCloud2, queue_size=10)
depth_pub = rospy.Publisher('/zed/depth', Float32MultiArray, queue_size=10)


zed = sl.Camera()
init_params = sl.InitParameters()
init_params.camera_resolution = sl.RESOLUTION.HD720
init_params.depth_mode = sl.DEPTH_MODE.ULTRA
init_params.coordinate_units = sl.UNIT.MILLIMETER
init_params.camera_fps = 15

runtime_params = sl.RuntimeParameters()
err = zed.open(init_params)
if err != sl.ERROR_CODE.SUCCESS:
    print('Camera initialization failed')
    exit(-1)

image = sl.Mat()
depth = sl.Mat()
point_cloud = sl.Mat()
bridge = CvBridge()

print("Camera Node Running...")

while not rospy.is_shutdown():
    if zed.grab(runtime_params) == sl.ERROR_CODE.SUCCESS:
        # Retrieve the image, depth, and point cloud
        zed.retrieve_image(image, sl.VIEW.LEFT)
        zed.retrieve_measure(depth, sl.MEASURE.DEPTH)
        zed.retrieve_measure(point_cloud, sl.MEASURE.XYZRGBA)

        # Convert to ROS messages
        img_msg = bridge.cv2_to_imgmsg(image.get_data(), encoding="bgr8")
        point_cloud_msg = PointCloud2()  # Conversion from sl.Mat to PointCloud2 is required
        depth_msg = Float32MultiArray(data=depth.get_data().flatten())

        # Publish the data
        image_pub.publish(img_msg)
        point_cloud_pub.publish(point_cloud_msg)
        depth_pub.publish(depth_msg)

    rospy.sleep(0.1)
